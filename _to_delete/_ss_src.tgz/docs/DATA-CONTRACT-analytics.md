# DATA-CONTRACT — секция «Аналитика» boom-cmd

> Публичный документ (docs/ репозитория). Полный контракт между данными и фронтом:
> форма ответа API, типы, правила агрегации за период, обращение с пропусками.
> Реальные данные живут вне репозитория; разработка ведётся на фикстуре
> `src/data/analytics.mock.json` (та же форма, выдуманные значения).
> Русские подписи UI — словарь в этом файле. Источник истины схемы — архитектор.

## 1. Эндпойнт

- URL: `import.meta.env.VITE_ANALYTICS_API` (GitHub Actions vars, в репо нет).
- `GET {API}?key={фраза}` — паттерн ключа тот же, что у «Задач» (useAccessKey).
- Нет/неверный ключ → `{"error":"unauthorized"}` → logout('unauthorized').
- Успех → JSON:

```json
{
  "updated": "ISO-дата генерации",
  "revenue": [...], "players": [...], "cards": [...],
  "game_econ": [...], "prizes": [...], "reviews": [...]
}
```

Элемент массива = строка месяца: `{"park": "ohta|piterland|mari", "month": "YYYY-MM", ...поля}`.
`month` — строка. Числа — number. Отсутствие данных — `null` ИЛИ отсутствие ключа
(обрабатывать оба случая одинаково). Фронт — read-only, никаких записей.

## 2. Поля и русские подписи

`park`: ohta=Охта Молл, piterland=Питерленд, mari=MARI (см. src/data/parks.js).

| Домен (RU вкладка) | Поле | Подпись UI | Ед. |
|---|---|---|---|
| revenue (Пополнения) | total_revenue | Итого выручка | ₽ |
| | cashless / cash / website | Безнал / Нал / Сайт | ₽ |
| | receipts | Чеки | шт |
| players (Игроки) | visitors_total / new_visitors | Посетителей всего / Новых | чел |
| | new_share_pct | Доля новых | % |
| | capture_rate_pct | Capture rate (от трафика ТЦ) | % |
| cards (Карты) | cards_in_system | Карт в системе | шт |
| | returning_pct | Вернувшихся | % |
| | avg_visits | Средних визитов | виз./карту |
| | outstanding_points_rub | Непогашенные очки-деньги | ₽ |
| | unredeemed_tickets_qty | Невыкупленные тикеты | шт |
| | max_payment_rub | Макс. платёж | ₽ |
| game_econ (Чек игры) | games | Игры | шт |
| | avg_game_price | Средняя цена игры | ₽ |
| | game_revenue | Игровая выручка (очки-деньги) | ₽ |
| | tickets_issued / bonus_points | Тикетов выдано / Бонусные очки | шт / ₽ |
| | ticket_loop_pct | Тикетный контур | % |
| | payout_share_pct | Payout от игровой выручки | % |
| prizes (Призотека) | prizes_given | Призов выдано | шт |
| | prize_cost | Себестоимость | ₽ |
| | profitability_pct | Прибыльность | % |
| | payout_target_pct | Payout призотеки (цель 20–25%) | % |
| | payout_share_pct | Payout от игровой выручки | % |
| reviews (Отзывы) | yandex_total / twogis_total | Отзывы Яндекс / 2ГИС (всего) | шт |
| | yandex_growth | Прирост Яндекс за месяц | шт |

Семантика: `game_revenue` ≠ `total_revenue` (очки-деньги vs пополнения — не путать).
Тикеты (шт) и очки (₽) не складывать. `payout_share_pct` встречается в двух доменах —
это одна метрика, значения совпадают.

## 3. Агрегация за период — ГЛАВНОЕ. Не выдумывать, применять таблицу

Период = Месяц / 3 месяца / Год (последние N месяцев, у которых есть строки).
**Проценты и средние НЕЛЬЗЯ усреднять в лоб** — только правила ниже.

| Правило | Поля | Формула за период |
|---|---|---|
| СУММА | total_revenue, cashless, cash, website, receipts, visitors_total, new_visitors, games, game_revenue, tickets_issued, bonus_points, prizes_given, prize_cost, yandex_growth | Σ по месяцам периода |
| ПЕРЕСЧЁТ из компонентов | avg_game_price | Σgame_revenue / Σgames |
| | new_share_pct | Σnew_visitors / Σvisitors_total × 100 |
| | ticket_loop_pct | Σ(game_revenue × ticket_loop_pct/100) / Σgame_revenue × 100 |
| | payout_share_pct | Σprize_cost / Σgame_revenue × 100 |
| | payout_target_pct | Σprize_cost / Σ(prize_cost / (payout_target_pct/100)) × 100 |
| | profitability_pct | 100 − payout_target_pct(период) |
| | средний чек (производная) | Σtotal_revenue / Σreceipts |
| ПОСЛЕДНИЙ месяц периода (накопительные, точка во времени) | cards_in_system, outstanding_points_rub, unredeemed_tickets_qty, yandex_total, twogis_total | значение самого позднего месяца с данными |
| МАКСИМУМ | max_payment_rub | max по месяцам (high-water mark) |
| ПОМЕСЯЧНО / приближённо | returning_pct, avg_visits, capture_rate_pct | за период НЕ сворачивать в одно число без оговорки: показывать тренд по месяцам, либо взвешенное по visitors_total значение с пометкой «≈» |

## 4. Пропуски (null) — честность обязательна

1. null не интерполировать, не заменять нулём. В UI — прочерк «—».
2. СУММА за период при дырах: считать по имеющимся месяцам и ПОКАЗЫВАТЬ
   неполноту (бейдж/подпись «данные за N из M мес»). Молча выдавать частичную
   сумму как полную — запрещено.
3. ПЕРЕСЧЁТ: месяц входит в числитель и знаменатель только если есть ОБА
   компонента (иначе пропустить месяц целиком и показать неполноту).
4. Рост к прошлому периоду: считать только если оба периода полные по этому
   полю; иначе «—».
5. Известные системные дыры (не баги): Питерленд — reviews пусто (нет источника),
   capture_rate почти везде null; MARI — prizes пусто до добивки; Охта работает
   с 2025-09 (короткий ряд — норма). Полный контекст — у владельца/архитектора.

## 5. Загрузка и кэш на фронте

Паттерн useProjects: fetch при наличии ключа, состояние loading / error / data,
unauthorized → logout. Ответ можно держать в памяти сессии; повторный fetch —
по pull-to-refresh / повторному входу. Поле `updated` показывать как «данные от …».

## 6. Версионирование контракта

Новые поля могут появляться (добивка данных) — рендер не должен падать от
незнакомых ключей. Удалений/переименований без правки этого файла не бывает.
Вопросы и расхождения — к архитектору, не решать на месте.
