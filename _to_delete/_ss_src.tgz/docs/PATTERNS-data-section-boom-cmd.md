# PATTERNS · добавление data-раздела (Аналитика / Материалы) · `boom-cmd`

> Инструкция для ассистента-разработчика (в отдельном чате с доступом к репо).
> Описывает, **как сделать новый раздел с живыми данными так же**, как сделан
> раздел «Проекты» (Фаза 4). Цель — единый подход: один источник-composable,
> общий гейт, keep-alive, скелетоны-перелив, парк-контекст, токены.
>
> Источники истины: `PRODUCT-PRINCIPLES` (продукт/IA), `DESIGN-STANDARD` (визуал),
> `AUTH-AppsScript` (источник/гейт). Эта памятка их не заменяет, а показывает,
> как сложить из них новый раздел. При конфликте — сигналь владельцу, не додумывай.

---

## 0. Что уже готово и переиспользуется (НЕ дублировать)

| Механика | Где живёт | Что делает |
|---|---|---|
| **Гейт на весь вход** | `src/composables/useAccessKey.js` + `App.vue` | Одна общая фраза, в памяти вкладки, таймаут 1ч. Всё приложение уже за гейтом — **новому разделу свой вход НЕ нужен**. |
| **keep-alive экранов** | `src/components/AppShell.vue` | Экраны не размонтируются при смене вкладки — данные не перезагружаются. Новый экран получает это **бесплатно**. |
| **Анимации загрузки** | `src/styles/main.css` | `.bc-skeleton` (перелив) и `.bc-fade-in` (плавное появление). Уважают `prefers-reduced-motion`. |
| **Парк-контекст** | `src/composables/useParkContext.js` | Глобальный фильтр `network` \| id парка (чистое разделение). |
| **Образец источника** | `src/composables/useProjects.js` | Эталон data-composable. Новый раздел — копия этого паттерна. |

Главный принцип: **новый раздел отличается от Проектов только своим
composable-источником, экраном и (опц.) листом данных.** Гейт, keep-alive и
анимации не трогаем — они общие.

---

## 1. Рецепт нового раздела (по шагам)

### 1.1. Composable-источник — единственная точка работы с данными
Скопируй структуру `useProjects.js` в `src/composables/use<Section>.js`
(напр. `useMaterials.js`). Обязательно:

- Публичный API: `{ data, loading, error, reload }` (имя `data` — по смыслу:
  `materials`, `metrics`…).
- URL — из env (см. §2). Фраза — **из общего гейта**, не из своего localStorage:
  ```js
  import { useAccessKey } from './useAccessKey.js'
  const { getKey, logout } = useAccessKey()
  ```
- Свой `normalize()` — **это и есть контракт раздела**. Устойчив к мусору
  (числа, пустые строки, лишние поля), фильтрует неполные записи.
- **Правило источника R2** (фейк не должен уехать в прод под видом live):
  ```js
  if (!API) {
    if (import.meta.env.DEV) { data.value = await loadMock(); return } // dev-мок, ленивый импорт
    throw new Error('Источник данных не настроен')                     // prod — громко, НИКОГДА не мок
  }
  ```
  Прямой `import.meta.env.DEV` (не компаундный флаг) — чтобы DCE выкинул мок-чанк из прод-бандла.
- Запрос: `GET ${API}?key=${encodeURIComponent(getKey())}` (+ `&action=<section>`,
  см. §2). Без кастомных заголовков (иначе CORS-preflight). `redirect:'follow'`
  по умолчанию — Apps Script 302 проходит.
- `{ error:'unauthorized' }` в рантайме → `logout('unauthorized')` (выкинет на вход).
- Сохрани отладку `?mockError=1` (симуляция ошибки загрузки).
- `load()` вызывается один раз в теле composable; `reload: load` — наружу.

> keep-alive держит экран живым, так что фабрика-composable (новые ref-ы на
> mount) грузит данные один раз и больше не перезагружает при смене вкладок.
> Синглтон делать не обязательно.

### 1.2. Backend (Apps Script) — расширить, не плодить
Та же web-app/тот же гейт. В `doGet` добавь **маршрут по `action`**, каждый
раздел читает свой лист/диапазон и отдаёт форму, которую ждёт его `normalize()`:

```javascript
function doGet(e) {
  var p = e && e.parameter ? e.parameter : {};
  var expected = PropertiesService.getScriptProperties().getProperty('ACCESS_KEY');
  if (!expected || p.key !== expected) return json({ error: 'unauthorized' });

  switch (p.action) {
    case 'materials': return json({ materials: readMaterials() });
    case 'analytics': return json({ metrics: readAnalytics() });
    default:          return json({ projects: readProjects() }); // совместимость
  }
}
```
- `ACCESS_KEY` и `SHEET_ID` — только в Script Properties (не в коде/репо).
- Маппинг Sheet→JSON чини под `normalize()` раздела; **контракт `normalize()`
  на фронте — источник истины, его не меняем под данные**.
- После правок `Code.gs` — **Deploy → Manage deployments → Edit → New version**,
  иначе URL отдаёт старую версию.

### 1.3. Экран — те же четыре состояния
В `src/screens/<Section>Screen.vue` повтори каркас `ProjectsScreen.vue`:

1. **loading** — скелетоны с переливом: класс `bc-skeleton` на плейсхолдерах
   (форму подгони под контент раздела).
2. **error** — центрированный экран + кнопка «Повторить» → `reload`.
3. **empty** — пустой стейт **с учётом парк-контекста** (текст «Вся сеть» vs имя парка).
4. **data** — контент с `bc-fade-in` (на контейнере/карточках).

Парк-фильтр — через `useParkContext` по **чистому разделению** (как в
`ProjectsScreen`):
```js
const { isNetwork, current } = useParkContext()
const visible = computed(() =>
  isNetwork.value
    ? data.value.filter((x) => x.parks === 'network')
    : data.value.filter((x) => Array.isArray(x.parks) && x.parks.includes(current.value)),
)
```
В `App.vue` у рабочих вкладок уже `parkFilter: true` — пилюля фильтра в шапке
появится сама.

### 1.4. Дизайн — строго по стандарту
- Только токены `var(--…)`, **хардкод hex запрещён** (все hex — в `main.css`).
- **Монохром по умолчанию; цвет — только функциональный** (срочность `--negative`,
  активное `--accent`, данные графиков `--positive`/`--negative`, статус-маркер
  `--st-*` как точка/заливка-марка). **Текст всегда монохромный** (§3.5).
- Анимации — только `.bc-skeleton` / `.bc-fade-in`; не плодить свои кейфреймы
  без причины.

### 1.5. i18n и данные
- Данные/значения — **английские** (enum, id). UI — **русский** через слой
  `src/i18n/<section>.js` (как `projects.js`). Имена парков — из `src/data/parks.js`,
  не дублировать.
- Мок раздела — `src/data/<section>.mock.json` (форма = что отдаёт live).

---

## 2. Env / endpoint

- Сейчас URL живёт в `VITE_PROJECTS_API` (`.env.local` локально + repo **Variable**
  в GitHub Actions). Разделы ходят в **тот же web-app** с разным `?action=` →
  переиспользуй ту же переменную.
- Если позже захочется нейтральное имя — можно завести `VITE_DATA_API` и
  перенацелить все composable-источники синхронно (мелкий рефактор, по согласованию).
- **Фразу доступа НЕ класть** ни в env, ни в код, ни в бандл — только память
  вкладки через `useAccessKey` (см. `AUTH-AppsScript §6`).

---

## 3. Чего НЕ делать (красные флаги)

- ❌ Свой вход/форма пароля в разделе — гейт уже глобальный (`useAccessKey`).
- ❌ Свой `localStorage`/`sessionStorage` для фразы — она только в памяти.
- ❌ Рефетч на каждый mount / размонтирование с перезагрузкой — keep-alive это решает.
- ❌ Хардкод hex, цветной текст, цвет ради декора.
- ❌ Менять `normalize()` под кривые данные из листа — чини маппинг Apps Script.
- ❌ URL/ключ в репозитории; деплой не-Anyone; правка KB без явного diff.

---

## 4. Чек-лист приёмки (прогнать самому)

```
[ ] npm run build зелёный; base /boom-cmd/, нет 404
[ ] grep по dist: фразы/ACCESS_KEY нет; мок-чанка в проде нет
[ ] нет хардкода hex в новых файлах (только var(--…))
[ ] состояния loading(скелетон-перелив)/error(Повторить)/empty(scope)/data(fade-in)
[ ] парк-фильтр: «Вся сеть» = только network; парк = только его записи
[ ] unauthorized в рантайме → выкидывает на вход; ?mockError=1 работает
[ ] контракт normalize() раздела совпадает с формой live и мока
```

Self-check в конце артефакта:
```
[✓] DESIGN-STANDARD (токены/монохром/текст)
[✓] PRODUCT-PRINCIPLES (IA/парк-контекст/read-only)
[✓] AUTH-AppsScript (гейт/env/Anyone)
[!] Расхождения/уточнения: …
[⚠] Открытые вопросы к владельцу: …
```

---

## 5. Файлы-образцы (копировать паттерн отсюда)

- Источник: `src/composables/useProjects.js`, `src/composables/useAnalytics.js`
- Гейт: `src/composables/useAccessKey.js` (+ `src/components/AccessKeyForm.vue`)
- Оболочка/keep-alive: `src/components/AppShell.vue`
- Экран (4 состояния + парк-фильтр): `src/screens/ProjectsScreen.vue`,
  `src/screens/AnalyticsScreen.vue`
- Анимации: `src/styles/main.css` (`.bc-skeleton`, `.bc-fade-in`)
- Парк-контекст: `src/composables/useParkContext.js`, `src/data/parks.js`
- Backend/гейт/деплой: `docs/AUTH-AppsScript-boom-cmd.md`

---

## 6. Реализованные разделы и нюансы

### 6.1. Проекты (Фаза 2 + ревизии)
Эталон паттерна. Чистое разделение парк-фильтра по `parks === 'network'` /
парк-id. Контракт нормализации — `normalizeProject()`.

### 6.2. Аналитика (Фаза 5a — на фикстуре, до интеграции)
Образец для разделов **со сложной агрегацией за период**. Что вынесено
сверх паттерна Проектов:

- **Контракт отдельным файлом:** `docs/DATA-CONTRACT-analytics.md` —
  форма ответа, поля и подписи (§2), правила агрегации §3, пропуски §4.
  Контракт правит **архитектор**, фронт не меняет правила «на месте».
- **Чистая функция агрегаций:** `src/composables/analyticsAggregate.js`
  (нет vue/DOM). Реализует §3 построчно (СУММА / ПЕРЕСЧЁТ / ВЗВЕШЕННОЕ —
  одно- и кросс-доменные / ПОСЛЕДНИЙ месяц / МАКСИМУМ / monthlySeries /
  growthVsPrev / completeness). На этот файл ревью идёт построчно
  относительно §3 контракта.
- **Самопроверка:** `scripts/verify-analytics.mjs` — пересчёт 8 чисел
  приёмки и кейсов пропусков по фикстуре. Регрессия в агрегациях упадёт
  сразу. Запуск: `node scripts/verify-analytics.mjs`.
- **Семантика «Вся сеть» отличается от Проектов:** в Аналитике
  общесетевых строк не бывает (каждая строка с конкретным парком), поэтому
  `'network'` = **агрегат по всем паркам** по правилам §3. Это сознательное
  расхождение, явно маршрутизируется в `computeContext()`. Если делаешь
  новый data-раздел — заранее ответь, какая семантика «сети» нужна, и
  отрази в его агрегациях.
- **«Последний месяц» по сети:** сумма последних значений каждого парка
  + флаг `multipleDates`/`byPark` для подписи разных дат
  (`MultiDateNotice.vue`). Молчаливая сумма «декабрь одного парка с маем
  другого» — баг.
- **Caption над H1:** `src/composables/useNavCaption.js` — синглтон для
  опциональной мелкой подписи над крупным заголовком в шапке (например
  «данные от …»). Экран ставит на `onActivated`, чистит на `onDeactivated`
  (keep-alive).
- **Графики на чистом SVG:** `MonthlyTrend.vue` (bar / line / sparkline)
  без зависимостей. Новые зависимости (sparkline-фреймворки, chart-libs)
  — только с явным согласованием.
