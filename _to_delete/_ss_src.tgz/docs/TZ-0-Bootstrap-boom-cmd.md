# ТЗ-0 · Bootstrap — `boom-cmd`

> **Прочитай `00_NAVIGATOR-boom-cmd.md` перед этим файлом.**
> Это Фаза 0. Её единственная цель — **доказать, что целевой стек собирается
> и пайплайн `push → GitHub Pages` работает end-to-end**, на примере одной
> страницы со словом «Привет!».

---

## 1. Что делаем и чего НЕ делаем

**Делаем:** голый каркас на целевом стеке (Vue 3 + Vite + Tailwind 3 +
lucide-vue-next + рукописный PWA-слой) + одна страница «Привет!» + рабочий
GitHub Actions деплой на Pages.

**НЕ делаем в Фазе 0:**
- ❌ разделы Командного центра (Аналитика / Задачи / Материалы) и навигацию;
- ❌ подключение Google Sheets / Apps Script / `fetch` данных;
- ❌ перенос компонентов из других проектов;
- ❌ решение открытых вопросов из навигатора §6.

Ожидаемый результат: на `https://<username>.github.io/boom-cmd/` открывается
страница «Привет!», приложение ставится как PWA, сборка зелёная.

---

## 2. Стек и версии (зафиксированы)

Ставь эти версии. Если конкретная версия не встаёт — поставь ближайшую
совместимую и **сообщи владельцу**, не меняй стек молча.

| Пакет | Версия |
|---|---|
| `vue` | `^3.5` |
| `vite` | `^8` |
| `@vitejs/plugin-vue` | `^6` |
| `tailwindcss` | `^3.4` |
| `postcss` | `^8.5` |
| `autoprefixer` | `^10` |
| `lucide-vue-next` | `^1` |

Язык — **JavaScript** (не TypeScript). `"type": "module"`.

---

## 3. Шаги реализации

### Шаг 1 — Инициализация проекта
```bash
npm create vite@latest boom-cmd -- --template vue
cd boom-cmd
npm install
npm install lucide-vue-next
npm install -D tailwindcss@^3.4 postcss autoprefixer
npx tailwindcss init -p   # создаёт tailwind.config.js + postcss.config.js
```

### Шаг 2 — `vite.config.js`
```js
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  base: '/boom-cmd/',   // ← синхронизировано с именем репозитория
})
```

### Шаг 3 — Tailwind
`tailwind.config.js`:
```js
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: { extend: {} },
  plugins: [],
}
```
`postcss.config.js`:
```js
export default {
  plugins: { tailwindcss: {}, autoprefixer: {} },
}
```
`src/styles/main.css`:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Шаг 4 — `src/main.js`
```js
import { createApp } from 'vue'
import './styles/main.css'
import App from './App.vue'

createApp(App).mount('#app')

// PWA service worker (base-aware для GitHub Pages)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register(import.meta.env.BASE_URL + 'sw.js')
      .catch(() => {})
  })
}
```

### Шаг 5 — `index.html` (PWA-мета)
```html
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/boom-cmd/favicon.svg" />
    <link rel="apple-touch-icon" href="/boom-cmd/apple-touch-icon.png" />
    <link rel="manifest" href="/boom-cmd/manifest.json" />
    <meta name="viewport"
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="БумБастик" />
    <meta name="application-name" content="БумБастик" />
    <meta name="theme-color" content="#000000" />
    <title>Панель управления БумБастик</title>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/main.js"></script>
  </body>
</html>
```

### Шаг 6 — PWA-ассеты в `public/`
`public/manifest.json`:
```json
{
  "name": "Панель управления БумБастик",
  "short_name": "БумБастик",
  "description": "Внутренний BizOps-пульт БумБастик",
  "start_url": "/boom-cmd/",
  "display": "standalone",
  "background_color": "#000000",
  "theme_color": "#000000",
  "orientation": "portrait",
  "icons": [
    { "src": "/boom-cmd/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "/boom-cmd/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
    { "src": "/boom-cmd/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable" },
    { "src": "/boom-cmd/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```
`public/sw.js` (cache-first статика, network-first навигация):
```js
const CACHE_NAME = 'boom-cmd-v1';
const BASE = '/boom-cmd/';
const STATIC_ASSETS = [
  BASE, BASE + 'index.html', BASE + 'favicon.svg',
  BASE + 'icon-192.png', BASE + 'icon-512.png',
  BASE + 'apple-touch-icon.png', BASE + 'manifest.json',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then((c) => c.addAll(STATIC_ASSETS)));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) =>
    Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', (e) => {
  const { request } = e;
  if (request.mode === 'navigate') {
    e.respondWith(fetch(request).catch(() => caches.match(BASE + 'index.html')));
    return;
  }
  e.respondWith(caches.match(request).then((cached) => cached ||
    fetch(request).then((res) => {
      if (res.ok && request.method === 'GET') {
        const clone = res.clone();
        caches.open(CACHE_NAME).then((c) => c.put(request, clone));
      }
      return res;
    })));
});
```
**Иконки/favicon:** положи плейсхолдеры `icon-192.png`, `icon-512.png`,
`apple-touch-icon.png`, `favicon.svg` в `public/`. Дизайн-иконки — позже,
сейчас годятся любые валидные картинки нужных размеров.

### Шаг 7 — `src/App.vue` (страница «Привет!»)
Минимум на Tailwind, без логики. Допустимо использовать иконку из
`lucide-vue-next`, чтобы заодно проверить, что пакет подключён:
```vue
<script setup>
import { Sparkles } from 'lucide-vue-next'
</script>

<template>
  <main class="min-h-screen flex flex-col items-center justify-center gap-4 bg-black text-white">
    <Sparkles class="w-10 h-10" />
    <h1 class="text-4xl font-bold tracking-tight">Привет!</h1>
    <p class="text-sm text-neutral-400">Панель управления БумБастик · Фаза 0</p>
  </main>
</template>
```

### Шаг 8 — Деплой через GitHub Actions
`.github/workflows/deploy.yml`:
```yaml
name: Deploy
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: false
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist
  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

---

## 4. Связка с GitHub (делает владелец, ты — инструктируешь)

1. **GitHub Desktop:** File → Add local repository → выбрать папку `boom-cmd`
   (Vite уже сделал `git init`). Commit всех файлов в `main`.
2. **Publish repository** → имя `boom-cmd`.
   ⚠️ Для бесплатного GitHub Pages репозиторий должен быть **public**
   (либо аккаунт Pro). Если выбрал private на free-тарифе — Pages не включится.
3. **На github.com:** репозиторий → **Settings → Pages → Source = GitHub Actions**.
4. Push в `main` запускает workflow. После зелёной сборки открой
   `https://<username>.github.io/boom-cmd/`.

---

## 5. Где прошит `base` (единый реестр для будущего переезда)

При смене имени репо ИЛИ переходе на домен `b00m-cmd.ru` (→ `base: '/'`)
правки нужны во **всех** этих местах синхронно:

| Файл | Что |
|---|---|
| `vite.config.js` | `base` |
| `public/manifest.json` | `start_url` + все `src` иконок |
| `public/sw.js` | `const BASE` + список `STATIC_ASSETS` |
| `index.html` | `href` иконок и манифеста |
| `src/main.js` | `BASE_URL` — авто из Vite, править не нужно |
| `public/CNAME` | **только** при переходе на кастомный домен (создать с `b00m-cmd.ru`) |

---

## 6. Критерии приёмки

- [ ] `npm run dev` → локально открывается страница «Привет!».
- [ ] `npm run build` проходит без ошибок.
- [ ] `npm run preview` показывает страницу с правильным `base` (`/boom-cmd/`).
- [ ] После Publish + включения Pages = GitHub Actions: страница открывается
      на `https://<username>.github.io/boom-cmd/`.
- [ ] В консоли нет 404 по ассетам (подтверждает, что `base` совпал).
- [ ] DevTools → Application: `manifest.json` валиден, SW зарегистрирован
      без ошибок, доступна установка приложения («Установить»).
- [ ] Стек соответствует §2; TypeScript не добавлен; drag-библиотек нет.
- [ ] Разделы, навигация и Sheets-интеграция НЕ добавлены (это Фаза 1–2).

---

## 7. Дальше

После зелёной Фазы 0 владелец даёт ТЗ на Фазу 1 (оболочка Командного центра:
3 раздела + навигация-заглушки). Секция «Задачи» (Фаза 2) строится по
`TEAM_ROADMAP_BRIEF.md`. См. порядок в `00_NAVIGATOR-boom-cmd.md` §3.
