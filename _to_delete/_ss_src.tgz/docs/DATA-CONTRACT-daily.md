# DATA-CONTRACT — под-страница «Контроль дня» (дневная выручка) boom-cmd

> Локальный документ (`docs/` репозитория — **gitignored**, наружу не уходит).
> Полный контракт между дневным слоем данных и фронтом: форма ответа API, табличная
> форма в Google Sheets, поля и русские подписи, правила МОДЕЛИ (её считает фронт),
> обращение с пропусками. Реальные дневные числа живут ВНЕ репозитория (приватный
> контур B + Google Sheets в рантайме под фразой доступа); разработка и приёмка логики
> ведутся на фикстуре `src/data/daily.mock.json` (та же форма, ЗАВЕДОМО выдуманные числа).
> Источник истины схемы — со-архитектор. Кросс-ссылки: BOUNDARY (контур B) стережёт границу,
> `tools/check_contract.py --daily` сверяет имена полей `boom-cmd-daily-front.xlsx` ↔ контракт/mock.

---

## 0. Место в продукте

Под-страница глубины 1 (subView `daily`), открывается с Главной, механика как «Парки».
IA (4 вкладки) НЕ меняется. Read-only: без drag&drop и правок из UI. Дизайн — только
семантические токены `var(--…)`, монохромный текст, сигналы через существующие
`--positive / --warning / --negative`; новых hex нет.

## 1. Эндпойнт

- URL: `import.meta.env.VITE_DAILY_API` → фолбэк `VITE_ANALYTICS_API`. На `VITE_PROJECTS_API`
  **НЕ** фолбэкать (другой деплой). Ветка `?action=daily` живёт в СУЩЕСТВУЮЩЕМ деплое
  **аналитики**, но он читает ОТДЕЛЬНУЮ дневную Google-таблицу по `openById(DAILY_SS_ID)`
  (изоляция день/месяц). URL источника в репозитории НЕТ (env на деплое).
- `GET {API}?key={фраза}&action=daily` — паттерн ключа общий (`useAccessKey`), `ACCESS_KEY` один на все экшены.
- Нет/неверный ключ → `{"error":"unauthorized"}` → `logout('unauthorized')`.
- `no-store` (источник — живая таблица; свежесть важнее HTTP-кэша). SW этот запрос не перехватывает.

## 2. Форма ответа API (`?action=daily`)

Объект повторяет форму приватного `boom-cmd-daily.json` (ключ `"<park>:<month>"`) + поле `updated`:

```json
{
  "updated": "ISO-дата (getLastUpdated дневной таблицы)",
  "sets": {
    "<park>:<YYYY-MM>": {
      "park": "ohta|piterland|iyun", "park_name": "…", "month": "YYYY-MM", "month_target": <number>,
      "days": [ { "date":"YYYY-MM-DD","dow":1..7,"status":"full|partial","outlier":<bool>,
                  "rev":<number>,"receipts":<number|null>,"chk":<number|null>,
                  "cashless":<number|null>,"cash":<number|null>,"topups":<number|null>,
                  "sessions":<number|null>,"new":<number|null>,"promo":<number|null>,
                  "rev_y":<number|null>,"rev_vk":<number|null> }, … ],
      "dow_coef": [7×number],   // индекс 0=Пн … 6=Вс
      "dow_n":    [7×number],   // чистых наблюдений по дню недели
      "dow_src":  [7×"данные|операторы"],
      "calib": { "weekday_base","tue_bonus","mon_dip","wknd_mult","min_obs","clean_n","weeks_equiv",
                 "oper_days":[…],"outliers":[…ISO],"note":"…" },
      "holidays": ["…ISO"],
      "cross_check": "…",
      "activities": [ { "code":"Г1","name":"…","days":["…ISO"] }, … ],
      "journal":    [ { "date":"…","n":<int>,"realized":<number>,"landing":<number>,
                        "landing_pct":<number>,"on_plan":<number>,"achievable":<bool> }, … ],
      "lead": { "name":"…","cur_avg":<number>,"prev_avg":<number|null>,
                "cur_label":"…","prev_label":"…|null","corr":<number|null> }   // опц.
    }
  }
}
```

`month` — строка. Числа — number. Пропуск = `null` ИЛИ отсутствие ключа (обрабатывать
одинаково). Незнакомые ключи не должны ронять рендер (§7). `park_name` фронт игнорирует —
имена парков берутся из `src/data/parks.js` (park_name в payload носит информативный характер).

## 3. Табличная форма в Google Sheets (4 вкладки)

Payload вложенный, а Sheets плоский → билдер `build_daily_front.py` (контур B) разворачивает
`boom-cmd-daily.json` в 4 вкладки; Apps Script собирает их обратно в объект §2. Порядок колонок
фиксирован. Списки склеены: `oper_days/outliers/holidays` — через `;`; `activities.days` — через пробел.
Пустая ячейка → `null`; `TRUE/FALSE` → `bool`.

**`daily_days`** (строка = парк × день):
```
park, month, date, dow, status, outlier,
rev, receipts, chk, cashless, cash, topups, sessions, new, promo, rev_y, rev_vk
```

**`daily_meta`** (строка = парк × месяц):
```
park, month, month_target,
coef_mon..coef_sun, n_mon..n_sun, src_mon..src_sun,
weekday_base, tue_bonus, mon_dip, wknd_mult, min_obs, clean_n, weeks_equiv,
oper_days, outliers, calib_note, holidays, cross_check,
lead_name, lead_cur_avg, lead_prev_avg, lead_cur_label, lead_prev_label, lead_corr
```

**`daily_journal`** (строка = парк × месяц × дата-снапшот):
```
park, month, date, n, realized, landing, landing_pct, on_plan, achievable
```

**`daily_activities`** (опц.):
```
park, month, code, name, days
```

## 4. Поля и русские подписи

`park`: ohta=Охта Молл, piterland=Питерленд, iyun=ТЦ Июнь (см. `src/data/parks.js`). MARI дневного слоя не имеет → пустой стейт.

| Группа | Поле | Подпись UI | Ед. |
|---|---|---|---|
| День | rev | Выручка | ₽ |
| | receipts / chk | Чеки / Средний чек | шт / ₽ |
| | cashless / cash | Безнал / Нал | ₽ |
| | topups / sessions | Пополнения / Сессии | шт |
| | new / promo | Новые гости / Акция | чел / шт |
| | rev_y / rev_vk | Отзывы Яндекс / ВК | шт |
| | status / outlier | full·partial / выброс | — |
| Месяц | month_target | Цель месяца | ₽ |
| | dow_coef[7] | Коэффициент дня недели | ×base |
| | dow_src[7] | данные · операторы (чип «допущение») | — |
| Журнал | realized / landing | Реализовано / Прогноз выручки | ₽ |
| | on_plan | Идём к плану | доля |
| | landing_pct | Прогноз к цели | доля |
| | achievable | Достижима без вмешательства | bool |
| Рычаг | lead.* | Главный рычаг (новые гости) | — |

`chk` в payload — производное `rev/receipts`; фронт пересчитывает сам, пришедшее значение — только sanity-check.
`попол/сессию = topups/sessions` (≈ попол/визит; НЕ ÷ все чеки). Метрика-колонка показывается,
только если у ≥1 дня набора есть значение (адаптивные колонки).

## 5. МОДЕЛЬ — её считает ФРОНТ (`dailyModel.js`), не Python

Коэффициенты (`dow_coef`) и журнал (`journal`) приходят посчитанными из Python — фронт их
**рендерит, не пересчитывает**. Всё остальное (план/прогноз/хвост/достижимость/метрики) —
на фронте. Формулы (порт инлайн-JS пультов, числа-в-число):

- **План дня:** `план[d] = T × coef[dow(d)] / Σ(coef по всем дням месяца)`. Инвариант: **Σплан = цель РОВНО**.
- **Заработано:** Σ `rev` полных дней (`status=full`), включая выбросы.
- **Темп прогноза `impliedBase`:** по полным дням БЕЗ выбросов — `Σrev_pace / Σweight_pace`.
- **Прогноз выручки (landing):** `реализовано + Σ(impliedBase × weight)` по будущим/незакрытым дням.
- **Хвост:** `план − факт` накопительно по неделям Пн–Вс.
- **Столбец «надо» будущего дня:** `adjBase × weight`, `adjBase = max(цель − факт, 0) / Σweight_остатка`. Это НЕ «прогноз».
- **Достижимость:** `adjBase(нужный темп) > maxObsBase(лучший обычный день)` → «без вмешательства не выйдем».
- **Цвет — единый `sigClass(ratio)`:** `≥1.00` → `--positive` · `0.85–0.99` → `--warning` · `<0.85` → `--negative`. Отдельных порогов не заводить.
- **Метрики:** `ср.чек = rev/receipts`; `попол/сессию = topups/sessions`; `нал/безнал` — как есть.
- **Статистика дней:** распределение полных дней по `sigClass(факт/план)`: выше (≥100)/близко (85–99)/ниже (<85).
- **Журнал:** НЕ считать — рендер `journal[]`; финальная точка обязана совпасть с текущим прогнозом (инвариант).
- **Две РАЗНЫЕ метрики (не путать):** `on_plan` = Σфакт/Σплан реализованных дней (темп к плану-на-дату);
  `landing_pct` = landing/цель (финальное приземление). В hero и verify разводятся раздельно.
- **Панель коэффициентов:** значения + `dow_src` + `calib.note`; дни на логике админов — чип `допущение`.

**Выброс** (`outlier=true`): вне калибровки и вне темпа приземления, но В факте — помечать на дне.
**`partial`**: не входит в калибровку и «факт недели как полный».

## 6. Парк-контекст

Глобальная пилюля (`useParkContext`). Конкретный парк {ohta,piterland,iyun} → полный дашборд.
MARI → пустой стейт. «Вся сеть» → мини-карты 3 парков + сетевые суммы (цели/факты суммируются;
план/прогноз = Σ по-парковых, каждый со своим `coef`); незрелость коэффициентов — чип `допущение`.
Месяц по умолчанию — последний (`max month` в наборе парка). Caption «данные от …» = `updated`
(фолбэк — max дата полного дня; «сегодня» НЕ подставлять).

## 7. Пропуски, кэш, версионирование

1. `null` не интерполировать, не заменять нулём — в UI прочерк «—».
2. Адаптивные колонки: метрика скрыта, если пуста у всех дней набора.
3. Новые поля могут появляться — рендер не падает от незнакомых ключей. Удалений/переименований
   без правки этого файла не бывает (согласованное событие: архитектор + фронт + контур B).
4. Ответ держим в памяти сессии; повторный fetch — по reload/повторному входу.

## 8. Приёмка логики (без реальных чисел)

`node scripts/verify-daily.mjs` гоняет `dailyModel` на `daily.mock.json` (выдуманные значения) и
пинует МАТ-ИНВАРИАНТЫ: `Σплан == цель`; пороги `sigClass` (1.00/0.85); финальная точка `journal ==
landing` модели; адаптивные колонки. Реальные числа в публичный `scripts/` НЕ кладутся — сверка с
приёмкой пультов (реальные значения) — приватный ручной шаг «уровня B» в контуре B.
