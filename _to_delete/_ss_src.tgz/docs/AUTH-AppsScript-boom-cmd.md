# AUTH · Apps Script — живой источник «Проекты» (Фаза 4)

> Read-only источник данных для раздела «Проекты»: Google Sheet → Apps Script
> `doGet` → JSON. Лёгкий гейт по одной общей фразе доступа. Бэкенда нет.
> Контракт данных — функция `normalize()` в `src/composables/useProjects.js`
> (её НЕ меняем; Apps Script обязан отдавать поля, которые она ждёт).
>
> **Другие data-разделы — свои Apps Script и свои Sheet** (Материалы → `TZ-5`,
> Аналитика → отдельно, Ф5b). Общий тут — только подход и парольная фраза.
>
> ⚠️ **В git этот файл не уходит** (`docs/` в `.gitignore`). Код Apps Script и
> `ACCESS_KEY` в репозиторий не коммитим.

---

## 1. Контракт данных (что обязан отдать `doGet`)

JSON вида `{ "projects": [ … ] }`. Каждый `project`:

| Поле | Тип | Примечание |
|---|---|---|
| `id` | string | непустой; иначе проект отбрасывается |
| `title` | string | непустой; иначе отбрасывается |
| `status` | string | EN-enum: `Backlog` / `Planned` / `In Progress` / `Done` |
| `priority` | number | 0–4 (0 None, 1 Urgent, 2 High, 3 Medium, 4 Low) |
| `directions` | array \| string | массив строк ИЛИ строка через запятую — `normalize()` разберёт оба |
| `parks` | `'network'` \| string[] \| `'all'` | `'network'`/`'all'` → общесетевой; массив id парков → парк-специфичный |
| `target` | string \| null | «ориентир»; пусто → `null` |
| `description` | string | |
| `items` | array | задачи/вехи проекта (ниже) |

`item`:

| Поле | Тип | Примечание |
|---|---|---|
| `id` | string | непустой; иначе item отбрасывается |
| `title` | string | непустой; иначе отбрасывается |
| `description` | string | |
| `type` | `'task'` \| `'milestone'` | всё, кроме `milestone`, трактуется как `task` |

> Источник истины — `normalizeProject` / `normalizeItem` в `useProjects.js`.
> `normalize()` устойчив к мусору (числа, пустые строки, лишние поля), но
> структуру выше выдерживать обязательно.

---

## 2. Гейт доступа

- `doGet` читает `e.parameter.key` и сравнивает с парольной фразой из
  `PropertiesService.getScriptProperties().getProperty('ACCESS_KEY')`.
- **Несовпадение / отсутствие** → `{ "error": "unauthorized" }` (HTTP 200, JSON).
- **Совпадение** → `{ "projects": [ … ] }`.
- Ответ **только** через `ContentService` (JSON). GET без кастомных заголовков —
  чтобы статичный origin (`github.io`) не словил CORS-preflight.
- Это **одна общая фраза**, не пользователи/роли. Права на правку данных =
  доступ к самой Google-таблице, а не роль в коде.
- **Та же фраза** должна быть прописана в `ACCESS_KEY` других Apps Script
  (Materials, Analytics…) — гейт на фронте один, проверяет ключ против
  Projects-эндпоинта (`useAccessKey.js`).

---

## 3. Структура таблицы (один лист)

**Один лист `Projects`** — по строке на проект; шапка в первой строке
(имена колонок = ключи):
```
id | title | status | priority | directions | parks | target | description | items
```
- `directions` — строка через запятую (`Маркетинг, Операции`).
- `parks` — `network` (или пусто) для общесетевого; для парк-специфичного —
  id парков через запятую (см. `src/data/parks.js`, напр. `ohta`).
- `items` — задачи и вехи проекта, **по одной на строку внутри ячейки**
  (перенос строки внутри ячейки — `Alt+Enter` / `Ctrl+Enter`):
  ```
  [Задача] Название :: Описание
  [Веха] Название :: Описание
  ```
  - тег `[Задача]` / `[Веха]` задаёт тип (`Веха`/`milestone` → `milestone`,
    иначе `task`); ` :: Описание` — необязательно;
  - id пункта генерируется автоматически (`<id проекта>-<номер>`); при желании
    можно задать явно через `|`: `[Веха|PRJ-014-3] Название`.

Связь «проект → задачи» теперь внутри строки проекта, отдельного листа `Items`
и колонки `project_id` больше нет.

---

## 4. Код Apps Script (`Code.gs`)

> Привязать скрипт к таблице (Extensions → Apps Script из самой таблицы),
> чтобы `SpreadsheetApp.getActiveSpreadsheet()` указывал на неё.

```javascript
function doGet(e) {
  var key = e && e.parameter ? e.parameter.key : '';
  var expected = PropertiesService
    .getScriptProperties()
    .getProperty('ACCESS_KEY');

  if (!expected || key !== expected) {
    return json({ error: 'unauthorized' });
  }
  return json({ projects: readProjects() });
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function readProjects() {
  // Sheet ID — из Script Properties (не хардкод). Фолбэк на привязанную таблицу,
  // если SHEET_ID не задан (для bound-скрипта).
  var sheetId = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  var ss = sheetId
    ? SpreadsheetApp.openById(sheetId)
    : SpreadsheetApp.getActiveSpreadsheet();
  var rows = sheetObjects(ss.getSheetByName('Projects'));

  return rows
    .map(function (p) {
      var id = String(p.id || '').trim();
      return {
        id: id,
        title: String(p.title || '').trim(),
        status: String(p.status || '').trim(),
        priority: Number(p.priority) || 0,
        directions: String(p.directions || ''), // normalize() сам разобьёт по запятой
        parks: parseParks(p.parks),
        target: p.target ? String(p.target).trim() : null,
        description: String(p.description || ''),
        items: parseItems(p.items, id)
      };
    })
    .filter(function (p) { return p.id && p.title; });
}

// Разбирает ячейку items (по строке на пункт) в массив { id, title, description, type }.
// Формат строки: "[Задача|Веха(|явный-id)] Название :: Описание".
function parseItems(cell, projectId) {
  var text = String(cell || '').trim();
  if (!text) return [];
  var out = [];
  text.split(/\r?\n/).forEach(function (line) {
    line = line.trim();
    if (!line) return;
    var type = 'task';
    var explicitId = '';
    var rest = line;
    var m = line.match(/^\[([^\]]*)\]\s*(.*)$/); // ведущий тег [..]
    if (m) {
      var tagParts = m[1].split('|');
      var label = String(tagParts[0] || '').trim().toLowerCase();
      if (label === 'веха' || label === 'milestone') type = 'milestone';
      if (tagParts[1]) explicitId = String(tagParts[1]).trim();
      rest = m[2];
    }
    var sep = rest.indexOf('::');
    var title = (sep >= 0 ? rest.slice(0, sep) : rest).trim();
    var description = sep >= 0 ? rest.slice(sep + 2).trim() : '';
    if (!title) return;
    out.push({
      id: explicitId || (projectId + '-' + (out.length + 1)),
      title: title,
      description: description,
      type: type
    });
  });
  return out;
}

function parseParks(v) {
  var s = String(v || '').trim();
  var low = s.toLowerCase();
  if (!s || low === 'network' || low === 'all') return 'network';
  return s.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
}

// Превращает лист в массив объектов {колонка: значение} по шапке (строка 1).
function sheetObjects(sheet) {
  if (!sheet) return [];
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0].map(function (h) { return String(h).trim(); });
  return values.slice(1).map(function (row) {
    var o = {};
    headers.forEach(function (h, i) { o[h] = row[i]; });
    return o;
  });
}
```

---

## 5. Что владелец делает руками (не автоматизируется кодом)

1. **Script Properties.** В редакторе Apps Script: Project Settings (шестерёнка) →
   Script Properties → добавить:
   - `ACCESS_KEY` = ваша парольная фраза (нигде в коде/репо/env не хранить);
   - `SHEET_ID` = id Google-таблицы (из её URL между `/d/` и `/edit`).
2. **Деплой web app.** Deploy → New deployment → тип **Web app**:
   - *Execute as:* **Me**;
   - *Who has access:* **Anyone**.
   Скопировать **Web app URL** (вида `https://script.google.com/macros/s/…/exec`).
3. **Локально (`.env.local`).** В корне репо создать `.env.local`:
   ```
   VITE_PROJECTS_API=https://script.google.com/macros/s/…/exec
   ```
   Файл в `.gitignore` — в git не уйдёт. URL — не секрет, но держим в env, не в коде.
4. **GitHub Actions.** Settings → Secrets and variables → Actions → **Variables** →
   `VITE_PROJECTS_API` = тот же Web app URL. Workflow прокидывает его в шаг build
   (`deploy.yml`, `env: VITE_PROJECTS_API: ${{ vars.VITE_PROJECTS_API }}`).
5. **Фраза доступа** вводится в приложении (форма гейта) и хранится только в
   `localStorage` браузера. В env/код/бандл не попадает.

---

## 6. Поток на фронте (как это работает)

Гейт — на **весь вход** (не только Проекты). Состояние держит синглтон
`src/composables/useAccessKey.js`; экран входа показывает `App.vue` вместо
оболочки, пока фраза не подтверждена.

**Сессия (безопасность).** Фраза **не сохраняется на диск** — только в памяти
вкладки. Значит, ввод требуется заново при любом полном открытии страницы:
запуск, обычный и **hard-reload**, повторное открытие после закрытия окна.
Плюс **абсолютный таймаут** `SESSION_TTL_MS` (по умолчанию 1 час): фоновый
страж раз в 30с проверяет срок и выкидывает на вход. Поменять срок — константа
в `useAccessKey.js`.

- Старт (`useAccessKey.init()`): память после загрузки пуста → экран входа
  (`AccessKeyForm.vue`, полноэкранный из `App.vue`). Сетевых вызовов на старте нет.
- Сабмит фразы → проверка против эндпоинта: `ok` → фраза в память + вход;
  `unauthorized` → «Неверная фраза доступа»; нет связи → «Нет связи с источником».
- В оболочке `useProjects` берёт фразу из `useAccessKey` и грузит проекты;
  ответ `{ error: 'unauthorized' }` в рантайме (напр. **сменили `ACCESS_KEY`**)
  → `logout('unauthorized')` выбрасывает на вход с пометкой «Доступ изменился».
  Истёк таймаут → `logout('expired')` с пометкой «Время сессии истекло».
  Прочие сетевые ошибки → экран ошибки с «Повторить».
- **dev + пустой URL** → гейт неактивен, фолбэк на мок (локальное удобство).
  **prod + пустой URL** → гейт неактивен, `useProjects` даёт громкую ошибку
  «Источник данных не настроен» (мок в прод под видом live не уходит — R2).
- Отладка: `?mockError=1` по-прежнему симулирует ошибку загрузки.

---

## 7. Грабли

- **302-редирект.** Web app на GET отвечает 302 на `*.googleusercontent.com`;
  обычный `fetch` (`redirect: 'follow'` по умолчанию) проходит за ним. Если
  меняете запрос — не ставьте `redirect: 'manual'` и не добавляйте кастомных
  заголовков (вернётся CORS-preflight, который Apps Script не обслужит).
- **Повторный деплой.** После правок `Code.gs` делайте **Manage deployments →
  Edit → New version**, иначе URL отдаёт старую версию.
- **Доступ Anyone** обязателен: статичный origin ходит без куки Google. Гейт —
  на уровне `ACCESS_KEY`, не на уровне Google-доступа к web app.
