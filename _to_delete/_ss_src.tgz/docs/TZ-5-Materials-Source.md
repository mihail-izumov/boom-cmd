# TZ-5 · Материалы — источник данных (Этап 1 Фазы 5)

> Подключение раздела «Материалы» к собственному живому источнику
> (отдельный Google Sheet + отдельный Apps Script). **Только источник +
> получение данных.** UI витрины — Этап 2 отдельным ТЗ.
>
> Источники истины: `PRODUCT-PRINCIPLES §4` (IA витрины), `DESIGN-STANDARD`,
> `AUTH-AppsScript-boom-cmd.md` (паттерн гейта/деплоя — применяем тот же,
> с собственным Web App), `PATTERNS-data-section §1` (рецепт раздела).

---

## 0. Скоуп

**В Этапе 1 делаем:**
- composable `src/composables/useMaterials.js` — единственная точка работы с источником;
- мок `src/data/materials.mock.json` (форма = live-ответ);
- **отдельный Apps Script** под лист «Материалы» (свой Code.gs, свой Web App URL);
- лист в Google Sheet владельца (`1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4`).

**Не делаем (Этап 2):**
- `MaterialsScreen.vue` — UI витрины (карточки, группировки, превью, открытие ссылок);
- `src/i18n/materials.js` — словари/форматтеры (если потребуются);
- любые изменения дизайна / шапки / парк-фильтра (флаг `parkFilter: true` на
  вкладке Материалы уже включён в `App.vue`).

---

## 1. Архитектура — отдельные источники, общий гейт

| Раздел | Sheet | Apps Script | env-переменная |
|---|---|---|---|
| Projects (Ф4) | свой Sheet | свой Web App | `VITE_PROJECTS_API` |
| **Materials (Ф5)** | **`1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4`** | **свой Web App** | **`VITE_MATERIALS_API`** |
| Analytics (Ф5b) | свой Sheet | свой Web App | `VITE_ANALYTICS_API` |

**Никаких `?action=…` и общих Web App.** Каждый раздел — независимый источник.
Если уронишь один Apps Script — остальные продолжат работать.

**Гейт остаётся глобальным** (`useAccessKey`). Чтобы фраза работала для всех
разделов, в **Script Properties каждого Apps Script** прописывается одно и
то же значение `ACCESS_KEY`. Это организационная договорённость, не код.
`useAccessKey` валидирует фразу против Projects-эндпоинта; если фразы в
скриптах разойдутся — Materials отдаст `unauthorized` и фронт выкинет на
экран входа.

---

## 2. Контракт данных (что приходит с бэка)

`GET ${VITE_MATERIALS_API}?key=<phrase>` → `{ "materials": [ … ] }`.

Каждый `material`:

| Поле | Тип | Примечание |
|---|---|---|
| `id` | string | непустой; иначе запись отбрасывается |
| `title` | string | непустой; иначе отбрасывается |
| `description` | string | свободный текст |
| `type` | string | RU-лейбл: `PDF` / `Папка` / `Изображение` |
| `status` | string | RU-лейбл: `Работает` / `На согласовании` / `В процессе` |
| `directions` | array \| string | массив или строка через запятую — `normalize()` разберёт оба |
| `parks` | `'network'` \| string[] | `'network'`/`'all'` → общесетевой; массив id парков → парк-специфичный |
| `last_updated` | string | `DD.MM.YYYY` (`05.02.2026`) — пока строка |
| `link` | string | `https://…` — внешняя (Drive); `materials/<file>` — локальный путь к `public/materials/` репо |

`normalize()` дополнительно вычисляет:

| Поле | Тип | Откуда |
|---|---|---|
| `href` | string | для внешних — равен `link`; для локальных — `import.meta.env.BASE_URL + path` (с обрезкой `/public/` и ведущего `/`) |
| `external` | boolean | `true` если `link` начинается с `http(s)://` |

> Источник истины контракта — `normalize()` в `useMaterials.js`.
> `normalize()` устойчив к мусору, новым ключам, пустым значениям; неполные
> записи (без `id` / `title`) отбрасываются молча.

### 2.1. Отклонение от §5 PRODUCT-PRINCIPLES (данные EN, UI RU)

Лейблы `type` / `status` / `directions` хранятся **по-русски** и используются
UI как есть. Согласовано явно: словари короткие, владельцу удобнее вести лист
по-русски, отдельный слой `i18n/materials.js` пока не нужен.

Последствия, которые принимаем:
- группировка/фильтрация UI работает по русским значениям;
- опечатка в листе ломает группу (UI должен пережить — записи с неизвестным
  значением просто попадут в «прочее» или останутся отдельной группой);
- если в будущем понадобится строгий enum (например, для сортировки или
  иконок типа), переедем на EN-ключи + словари без правки контракта Apps Script
  (контракт меняет архитектор).

---

## 3. Схема листа

Лист в Sheet `1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4`. Первый лист
(`gid=0`) можно назвать как угодно — Apps Script ниже читает **первый лист**
файла, привязан к нему. Шапка в строке 1:

```
id | title | description | type | status | directions | parks | last_updated | link
```

| Колонка | Значения |
|---|---|
| `id` | `DOC-001` … `DOC-026` (или любая непустая строка) |
| `title` | непустой |
| `description` | свободный текст |
| `type` | `PDF` / `Папка` / `Изображение` |
| `status` | `Работает` / `На согласовании` / `В процессе` |
| `directions` | строка; несколько — через запятую (`Маркетинг, b00m.fun`) |
| `parks` | `network` для общесетевого; id парка (`ohta`/`piterland`/`mari`/`iyun`) или несколько через запятую |
| `last_updated` | `DD.MM.YYYY` или ячейка-Date (Apps Script отформатирует к строке) |
| `link` | `https://drive.google.com/…` **или** `materials/<file>.jpg` (файлы уже лежат в `public/materials/` репо; без `/public/`, без ведущего `/`) |

26 записей берём из CSV-выгрузки (формат уже совпадает; для DOC-018…026
в `link` нужно убрать префикс `/public/`).

---

## 4. Код Apps Script (`Code.gs`)

Создать **новый** Apps Script, привязанный к Sheet
`1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4` (Extensions → Apps Script
из самой таблицы). В нём — следующий код:

```javascript
var SHEET_ID = '1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4';

function doGet(e) {
  var key = e && e.parameter ? e.parameter.key : '';
  var expected = PropertiesService
    .getScriptProperties()
    .getProperty('ACCESS_KEY');

  if (!expected || key !== expected) {
    return json({ error: 'unauthorized' });
  }
  return json({ materials: readMaterials() });
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function readMaterials() {
  // Sheet ID: Script Properties перебивает, иначе — константа выше.
  // Симметрично паттерну Projects Apps Script.
  var sheetId = PropertiesService.getScriptProperties().getProperty('SHEET_ID') || SHEET_ID;
  var ss = sheetId
    ? SpreadsheetApp.openById(sheetId)
    : SpreadsheetApp.getActiveSpreadsheet();
  // Лист — первый по порядку (gid=0). Если в файле будет несколько листов,
  // заменить на ss.getSheetByName('Materials').
  var sheet = ss.getSheets()[0];
  var rows = sheetObjects(sheet);

  return rows
    .map(function (m) {
      return {
        id: String(m.id || '').trim(),
        title: String(m.title || '').trim(),
        description: String(m.description || '').trim(),
        type: String(m.type || '').trim(),
        status: String(m.status || '').trim(),
        directions: String(m.directions || ''),     // normalize() сам разобьёт
        parks: parseParks(m.parks),
        last_updated: formatDateRu(m.last_updated), // даты Sheets → 'DD.MM.YYYY'
        link: String(m.link || '').trim()
      };
    })
    .filter(function (m) { return m.id && m.title; });
}

function parseParks(v) {
  var s = String(v || '').trim();
  var low = s.toLowerCase();
  if (!s || low === 'network' || low === 'all') return 'network';
  return s.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
}

// Sheets отдаёт ячейку-дату как Date. Надёжная проверка типа
// (instanceof Date в V8 Apps Script иногда возвращает false из-за разных
// realm-контекстов) + форматирование через Utilities.formatDate с timezone
// скрипта. На вход может прийти строка (legacy ввод) — отдаём как есть.
function formatDateRu(v) {
  if (v && Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) {
    var tz = Session.getScriptTimeZone() || 'GMT+3';
    return Utilities.formatDate(v, tz, 'dd.MM.yyyy');
  }
  return String(v || '').trim();
}

// Превращает лист в массив объектов {колонка: значение} по шапке (строка 1).
function sheetObjects(sheet) {
  if (!sheet) return [];
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0].map(function (h) { return String(h).trim(); });
  return values.slice(1).map(function (row) {
    var o = {};
    headers.forEach(function (h, i) { o[h] = row[i]; });
    return o;
  });
}
```

---

## 5. Поток на фронте

`useMaterials()` ведёт себя ровно как `useProjects()` / `useAnalytics()`
(PATTERNS §1.1):

- публичный API: `{ materials, loading, error, reload }`;
- URL — `import.meta.env.VITE_MATERIALS_API`;
- фраза — `useAccessKey.getKey()`; на `unauthorized` → `logout('unauthorized')`;
- правило R2: dev + пустой URL → ленивый мок; prod + пустой URL → громкая ошибка;
- `?mockError=1` симулирует ошибку загрузки;
- `load()` зовётся один раз в теле composable; `reload: load` — наружу.

Свой ввод пароля для Материалов **не делаем** — гейт уже глобальный
(`useAccessKey`).

---

## 6. Что делает владелец (последовательность)

1. **Лист** в Sheet `1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4`:
   - залить 26 строк CSV в первый лист (`gid=0`);
   - проверить шапку и колонки (см. §3);
   - в строках DOC-018…026 в колонке `link` убрать префикс `/public/` —
     должно быть `materials/<file>.jpg`.
2. **Apps Script** для этого Sheet:
   - открыть Extensions → Apps Script из самой таблицы (привязанный bound-скрипт);
   - вставить код из §4 в `Code.gs` — `SHEET_ID` уже захардкоден в коде
     (`1h6sF8k0KTIFwZPBE5-mDv9sn_0AqTQLB1QuuE9_C-L4`); менять, если переедешь
     на другой Sheet — либо в коде, либо через Script Properties (перебьёт);
   - Project Settings (шестерёнка) → Script Properties → добавить
     `ACCESS_KEY` = **та же фраза**, что в Projects Apps Script;
   - Deploy → New deployment → Web app:
     - *Execute as:* **Me**;
     - *Who has access:* **Anyone**;
   - скопировать **Web app URL** (`https://script.google.com/macros/s/…/exec`).
3. **Локально (`.env.local`)** — добавить строку:
   ```
   VITE_MATERIALS_API=https://script.google.com/macros/s/…/exec
   ```
4. **GitHub Actions** → Settings → Secrets and variables → Actions → **Variables**:
   - `VITE_MATERIALS_API` = тот же Web app URL.
   - В `.github/workflows/deploy.yml` шаг build получает её через
     `env: VITE_MATERIALS_API: ${{ vars.VITE_MATERIALS_API }}` (если ещё не
     прокинуто — добавить рядом с `VITE_PROJECTS_API`).
5. После любых правок `Code.gs` — **Deploy → Manage deployments → Edit →
   New version**, иначе URL отдаёт старый код.

---

## 7. Приёмка Этапа 1

```
[ ] npm run build зелёный; нет хардкода hex в новых файлах
[ ] grep по dist: мок-чанка materials.mock.json в проде НЕТ
[ ] в dev (без VITE_MATERIALS_API) useMaterials() отдаёт 26 записей из мока
[ ] в проде с верным URL + ключом приходит { materials: [...] }
[ ] unauthorized в рантайме → logout → экран входа
[ ] ?mockError=1 симулирует ошибку загрузки
[ ] нормализация link: http(s) → external=true; relative → href = BASE_URL+path
[ ] парк-фильтр совместим: 'network' видны только в «Вся сеть»; парк-id —
    только в виде этого парка (как Projects)
```

После приёмки — Этап 2 (UI витрины) отдельным ТЗ.

---

```
[✓] PRODUCT-PRINCIPLES §4 (IA витрины — каркас, без углубления UI)
[✓] DESIGN-STANDARD — не задеваем (Этап 1 без UI)
[✓] AUTH-AppsScript — паттерн гейта/деплоя применён, документ Projects не задет
[✓] PATTERNS-data-section §1 — соблюдён построчно
[!] Отклонение от §5 (RU-данные) зафиксировано явно (2.1)
[!] Отличие от Analytics: НЕТ `?action=` — отдельный Web App под раздел
[⚠] Открытые на Этап 2: IA группировки (тип vs направление), превью
    локальных vs Drive, как открывать Drive-ссылки
```
